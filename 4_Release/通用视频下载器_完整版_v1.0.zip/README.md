﻿# 通用视频下载器

多站点影视/动漫抓取下载工具（桌面版，Python + Tkinter）。

## 功能
- 主页：多站点（番剧/动漫/影视）搜索、扫描剧集、极速多线程下载、音视频合成
- 通用下载：yt-dlp 引擎，长视频（番剧/B站等）解析下载，音视频自动合并
- 资源嗅探：短视频等网页媒体，播放即自动捕获真实地址下载
- 视频转换：ffmpeg 无损/兼容格式转换
- 密码管理：登录 Cookie 加密容器

## 运行
安装依赖后：python gui.py

## 打包
PyInstaller：python -m PyInstaller VideoDownloader.spec
